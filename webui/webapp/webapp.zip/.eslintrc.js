// https://eslint.org/docs/user-guide/configuring

module.exports = {
  root: true,
  parserOptions: {
    parser: 'babel-eslint'
  },
  env: {
    browser: true,
  },
  extends: [
    // https://github.com/vuejs/eslint-plugin-vue#priority-a-essential-error-prevention
    // consider switching to `plugin:vue/strongly-recommended` or `plugin:vue/recommended` for stricter rules.
    'plugin:vue/essential',
    // https://github.com/standard/standard/blob/master/docs/RULES-en.md
    'standard'
  ],
  // required to lint *.vue files
  plugins: [
    'vue'
  ],
  // add your custom rules here
  rules: {
    // 生成器函数*的前后空格
    'generator-star-spacing': 'off',
    // 忽略end标签错误
    'vue/no-parsing-error': [2, { "x-invalid-end-tag": false }],
    // allow debugger during development
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    // 配置首行缩进
    'indent':0,
    //不检查分号
    'semi': 0,
    ////函数定义时括号前面要不要有空格
    'space-before-function-paren': 0
  }
}
