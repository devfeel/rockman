var test1 = function () { alert(11) }
export { test1 }