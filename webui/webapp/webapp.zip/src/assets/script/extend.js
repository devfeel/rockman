//对vue参数进行扩展
var extend = function (param) { 
    console.log(param)
 }
export { extend }